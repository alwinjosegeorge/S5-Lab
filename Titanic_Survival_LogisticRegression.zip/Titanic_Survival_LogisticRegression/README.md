# Titanic Passenger Survival Prediction (Logistic Regression)

Predicts whether a Titanic passenger survived from class, sex, age, siblings/spouses, parents/children, embarkation port and fare.

## Pipeline
1. Load data (891 passengers, source: seaborn-data `titanic.csv`)
2. Remove duplicate / leaking columns (`alive` is the target itself)
3. Encode: sex (binary), pclass and embarked (one-hot, drop_first)
4. Stratified 80/20 split (`random_state=42`)
5. Fill missing `age` with the **training** median (after the split)
6. StandardScaler (fit on train only)
7. Logistic Regression (`max_iter=1000`)
8. Evaluate: accuracy, precision, recall, F1, ROC-AUC, confusion matrix, feature importance
9. Threshold investigation (0.3 / 0.5 / 0.7)

## Results (test set, 179 passengers)
| Metric | Value |
|---|---|
| Accuracy | 80.45% |
| Precision | 79.31% |
| Recall | 66.67% |
| F1 | 72.44% |
| ROC-AUC | 84.22% |

| Threshold | Accuracy | Precision | Recall | F1 |
|---|---|---|---|---|
| 0.3 | 77.09% | 67.07% | 79.71% | 72.85% |
| 0.5 | 80.45% | 79.31% | 66.67% | 72.44% |
| 0.7 | 78.77% | 89.74% | 50.72% | 64.81% |

## Run
```
pip install -r requirements.txt
cd notebooks
jupyter notebook Titanic_Survival.ipynb
```
